#!/usr/bin/env python3

from fastapi import Path
from pydantic import BaseModel, Field
from typing import List
from beanie import Document


class Dname:
    STR = "The display name of the photographer"
    MAX_LENGTH = 16
    PATH_PARAM = Path(..., title=STR, max_length=MAX_LENGTH, examples="rdoisneau")

class Notes:
    INT = "The notes of the photographer"


class PhotographerNotes(BaseModel):
    display_name: str = Field(None, title=Dname.STR, max_length=Dname.MAX_LENGTH)
    notes: List[int] = Field(None, title=Notes.INT)
    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "display_name": "rdoisneau",
                    "notes": [3, 5, 4],
                }
            ]
        }
    }


# Model for Mongo
class Notes(Document, PhotographerNotes):
    pass

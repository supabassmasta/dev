#!/usr/bin/env python3

import uvicorn

from fastapi import Body, FastAPI, HTTPException, Path
from starlette.responses import Response
from fastapi.logger import logger
import requests
REQUEST_TIMEOUT = 5

from contextlib import asynccontextmanager
from pydantic_settings import BaseSettings
import pymongo
from models import (
    Dname,
    Notes,
    PhotographerNotes,
)
import docs

from beanie import init_beanie
import motor
from statistics import mean

class Settings(BaseSettings):
    mongo_host: str = "mongo"
    mongo_port: str = "27017"
    mongo_user: str = ""
    mongo_password: str = ""
    database_name: str = "notes"
    auth_database_name: str = "notes"

    photographer_host: str = "photographer-service"
    photographer_port: str = "80"

settings = Settings()

photographer_service = 'http://' + settings.photographer_host + ':' + settings.photographer_port + '/'

# FastAPI logging
# gunicorn_logger = logging.getLogger('gunicorn.error')
# logger.handlers = gunicorn_logger.handlers


################################################################################
@asynccontextmanager
async def startup_event(application: FastAPI):
    conn = f"mongodb://"
    if settings.mongo_user:
        conn += f"{settings.mongo_user}:{settings.mongo_password}@"
    conn += f"{settings.mongo_host}:{settings.mongo_port}"
    conn += f"/{settings.database_name}?authSource={settings.auth_database_name}"
    client = motor.motor_asyncio.AsyncIOMotorClient(conn)
    await init_beanie(
        database=client[settings.database_name], document_models=[Notes]
    )
    yield


app = FastAPI(
    title="Notes Service",
    # openapi_tags=docs.photographer_metadata,
    lifespan=startup_event,
)


################################################################################
@app.post(
    "/note/{display_name}",
    status_code=201,
    summary="Add a note for an existing Photographer",
    description=docs.create_photographers_doc,
    tags=["note"],
)
async def note_photographer(
    display_name: str = Path(
        title="The display name of the photographer",
        max_length=16,
        examples="rdoisneau",
    ),
    photographerNote: int = Body()
):
    try:
        photographer = requests.get(photographer_service + 'photographer/' + display_name,
                                    timeout=REQUEST_TIMEOUT)
        if photographer.status_code == requests.codes.ok:
            # Check if photographer exist in notes db
            check = await Notes.find_one(
                Notes.display_name == display_name
            )
            if check is None:
                # Create a new entry
                await Notes(**dict({"display_name":display_name, "notes":[photographerNote]})).insert()
            else:
                check.notes.append(photographerNote)
                await check.save()

        elif photographer.status_code == requests.codes.unavailable:
            raise HTTPException(status_code = 503, detail = "Mongo unavailable")
        elif photographer.status_code == requests.codes.not_found:
            raise HTTPException(status_code = 404, detail = "Photographer Not Found")

    except pymongo.errors.ServerSelectionTimeoutError:
        raise HTTPException(status_code=503, detail="Mongo unavailable")

################################################################################
@app.head(
    "/note",
    status_code=200,
    summary="Give notes to Photographers",
    description=docs.head_photographers_doc,
    tags=["note"],
)
async def head_photographers(response: Response) -> None:
    try:
        response.headers["X-Total-Count"] = str(await Notes.count())
    except pymongo.errors.ServerSelectionTimeoutError:
        raise HTTPException(status_code=503, detail="Mongo unavailable")


################################################################################
@app.get(
    "/note/{display_name}",
    status_code=200,
    summary="Get a list of photographer notes ",
    description=docs.get_photographers_doc,
    tags=["note"],
)
async def get_photographer_notes(
    response: Response,
    display_name: str = Path(
        title="The display name of the photographer",
        max_length=16,
        examples="rdoisneau",
    ),
) :
    notes_digests = list()
    last_id = 0
    try:
        response.headers["X-Total-Count"] = str(await Notes.count())
        check = await Notes.find_one(
            Notes.display_name == display_name
        )
        if check is None:
            raise HTTPException(status_code = 404, detail = "Photographer Not Found")
    except pymongo.errors.ServerSelectionTimeoutError:
        raise HTTPException(status_code=503, detail="Mongo unavailable")
    return {"photographer":display_name, "notes": check.notes}

########################################################################
@app.get(
    "/note/{display_name}/average",
    status_code=200,
    summary="Get average of photographer notes ",
    description=docs.get_photographers_doc,
    tags=["note"],
)
async def get_photographer_notes(
    response: Response,
    display_name: str = Path(
        title="The display name of the photographer",
        max_length=16,
        examples="rdoisneau",
    ),
) :
    notes_digests = list()
    last_id = 0
    try:
        response.headers["X-Total-Count"] = str(await Notes.count())
        check = await Notes.find_one(
            Notes.display_name == display_name
        )
        if check is None:
            raise HTTPException(status_code = 404, detail = "Photographer Not Found")
    except pymongo.errors.ServerSelectionTimeoutError:
        raise HTTPException(status_code=503, detail="Mongo unavailable")
    return {"photographer": display_name, "average note": mean(check.notes)}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
    # logger.setLevel(logging.DEBUG)
else:
    # logger.setLevel(gunicorn_logger.level)
    pass

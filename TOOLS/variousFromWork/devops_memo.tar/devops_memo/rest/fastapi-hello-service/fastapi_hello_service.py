#!/usr/bin/env python3

import uvicorn

from fastapi import FastAPI, HTTPException
from fastapi import Path

app = FastAPI()

@app.get("/hello", status_code=200)
def say_hello():
    return {'message': 'hello'}

# BEGIN ANSIBLE MANAGED BLOCK
# DO NOT REMOVE LINE ABOVE (used by Ansible)


@app.get("/hello/{firstname}", status_code=200)
def say_hello(firstname: str, level: str):
    if level=='familiar':
        return {'message': 'hello, ' + firstname + ' !'}
    elif level=='formal':
        return {'message': 'Nice to meet you, ' + firstname}
    else:
#        raise HTTPException(status_code=422, detail="Unexpected value for level query parameter")
        return {'message': 'Hi@app.get("/hello/{firstname}", status_code=200), ' + firstname}


@app.get("/hi/{firstname}", status_code=200)
def say_hi(firstname: str):
    return {'message': 'Hi, ' + firstname}


# DO NOT REMOVE LINE BELOW (used by Ansible)
# END ANSIBLE MANAGED BLOCK

if __name__ == "__main__":
    uvicorn.run(app, log_level="info")


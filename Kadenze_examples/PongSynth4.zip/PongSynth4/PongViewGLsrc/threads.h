//  #include <process.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>

void newStringByPipe(void);
void startPipeThread();

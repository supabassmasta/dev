PONG runs the animation

PONG4 runs it after you've hacked it to 
add KarplusBottle.ck and KarplusDrum.ck 
